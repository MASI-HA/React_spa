import React from "react";

const Users = () => {
  return <button className="btn-home-link">Users </button>;
};

export default Users;
