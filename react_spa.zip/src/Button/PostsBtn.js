import React from "react";

const Posts = () => {
  return <button className="btn-home-link"> Posts </button>;
};

export default Posts;
